import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';

@Component({
  selector: 'app-type-list',
  templateUrl: './type-list.component.html',
  styleUrls: ['./type-list.component.css']
})
export class TypeListComponent implements OnInit {
  types: any;
  currentType = null;
  currentIndex = -1;

  constructor(private expensesService: ExpensesService) { }

  ngOnInit(): void {
    this.retrieveTypes();
  }

  retrieveTypes() {
    this.expensesService.getType()
      .subscribe(
        data => {
          this.types = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveTypes();
    this.currentType = null;
    this.currentIndex = -1;
  }

  setActiveType(type, index) {
    this.currentType = type;
    this.currentIndex = index;
  }

  removeType(id) {
    this.expensesService.deleteType(id)
      .subscribe(
        response => {
          console.log(response);
          this.retrieveTypes();
        },
        error => {
          console.log(error);
        });

    this.refreshList();
  }
}
