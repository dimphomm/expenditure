import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-entry-details',
  templateUrl: './entry-details.component.html',
  styleUrls: ['./entry-details.component.css']
})
export class EntryDetailsComponent implements OnInit {
  currentEntry = null;
  message = '';

  constructor(
    private expensesService: ExpensesService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.message = '';
    this.getEntry(this.route.snapshot.paramMap.get('id'));
  }

  getEntry(id) {
    this.expensesService.getEntryId(id)
      .subscribe(
        data => {
          this.currentEntry = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  updateEntry() {
    this.expensesService.updateEntry(this.currentEntry.id, this.currentEntry)
      .subscribe(
        response => {
          console.log(response);
          this.message = 'The Expense Entry was updated successfully!';
        },
        error => {
          console.log(error);
        });
  }


}
