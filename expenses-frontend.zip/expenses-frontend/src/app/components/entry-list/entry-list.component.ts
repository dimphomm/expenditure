import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';

@Component({
  selector: 'app-entry-list',
  templateUrl: './entry-list.component.html',
  styleUrls: ['./entry-list.component.css']
})
export class EntryListComponent implements OnInit {
  entries: any;

  constructor(private expensesService: ExpensesService) { }

  ngOnInit(): void {
    this.retrieveEntries();
  }

  retrieveEntries() {
    this.expensesService.getEntry()
      .subscribe(
        data => {
          this.entries = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveEntries();
  }

  removeEntry(id) {
    this.expensesService.deleteEntry(id)
      .subscribe(
        response => {
          console.log(response);
          this.retrieveEntries();
        },
        error => {
          console.log(error);
        });

    this.refreshList();
  }

}
