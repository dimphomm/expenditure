import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-type-details',
  templateUrl: './type-details.component.html',
  styleUrls: ['./type-details.component.css']
})
export class TypeDetailsComponent implements OnInit {
  currentType = null;
  message = '';

  constructor(
    private expensesService: ExpensesService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.message = '';
    this.getType(this.route.snapshot.paramMap.get('id'));
  }

  getType(id) {
    this.expensesService.getTypeId(id)
      .subscribe(
        data => {
          this.currentType = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  updateType() {
    this.expensesService.updateType(this.currentType.id, this.currentType)
      .subscribe(
        response => {
          console.log(response);
          this.message = 'The Expense Type was updated successfully!';
        },
        error => {
          console.log(error);
        });
  }


}
