import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';

@Component({
  selector: 'app-add-entry',
  templateUrl: './add-entry.component.html',
  styleUrls: ['./add-entry.component.css']
})
export class AddEntryComponent implements OnInit {
  model: any;
  entry = {
    typeId: null,
    value: null,
    comment: ''
  };
  types1 = [
    {
      id: '1',
      name: 'Electricity'
    },
    {
      id: '2',
      name: 'Grocery'
    },
    {
      id: '3',
      name: 'Transport'
    }
  ];
  types = this.getEntries();
  typeId = '1';
  submitted = false;

  constructor(private expensesService: ExpensesService) { }

  ngOnInit(): void {
  }

  getEntries()
  {
    return this.expensesService.getType();
  }

  saveEntry() {
    const data = {
      typeId: this.entry.typeId,
      value: this.entry.value,
      comment: this.entry.comment
    };

    this.expensesService.createEntry(data)
      .subscribe(
        response => {
          console.log(response);
        },
        error => {
          console.log(error);
        });

    this.submitted = true;
  }

  newEntry() {
    this.submitted = false;
    this.entry = {
      typeId: 0,
      value: 0,
      comment: ''
    };
  }

}
