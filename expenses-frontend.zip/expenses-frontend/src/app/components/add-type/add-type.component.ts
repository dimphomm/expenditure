import { Component, OnInit } from '@angular/core';
import { ExpensesService } from 'src/app/services/expenses.service';

@Component({
  selector: 'app-add-type',
  templateUrl: './add-type.component.html',
  styleUrls: ['./add-type.component.css']
})
export class AddTypeComponent implements OnInit {
  type = {
    name: '',
    comment: ''
  };
  submitted = false;

  constructor(private expensesService: ExpensesService) { }

  ngOnInit(): void {
  }

  saveType() {
    const data = {
      name: this.type.name,
      comment: this.type.comment
    };

    this.expensesService.createType(data)
      .subscribe(
        response => {
          console.log(response);
        },
        error => {
          console.log(error);
        });

    this.submitted = true;
  }

  newType() {
    this.submitted = false;
    this.type = {
      name: '',
      comment: ''
    };
  }

}
