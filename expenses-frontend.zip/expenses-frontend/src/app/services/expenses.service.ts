import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const baseUrl = 'http://localhost:8080/api/expenses';

@Injectable({
  providedIn: 'root'
})
export class ExpensesService {

  constructor(private http: HttpClient) { }

  getType() {
    return this.http.get(baseUrl + '/type');
  }

  getEntry() {
    return this.http.get(baseUrl + '/entry');
  }

  getTypeId(id) {
    return this.http.get(`${baseUrl + '/type'}/${id}`);
  }

  getEntryId(id) {
    return this.http.get(`${baseUrl + '/entry'}/${id}`);
  }

  getTypeEntries(id) {
    return this.http.get(`${baseUrl + '/typeEntries'}/${id}`);
  }

  createType(data) {
    return this.http.post(baseUrl + '/type', data);
  }

  createEntry(data) {
    return this.http.post(baseUrl + '/entry', data);
  }

  updateType(id, data) {
    return this.http.put(`${baseUrl + '/type'}/${id}`, data);
  }

  updateEntry(id, data) {
    return this.http.put(`${baseUrl + '/entry'}/${id}`, data);
  }

  deleteType(id) {
    return this.http.delete(`${baseUrl + '/type'}/${id}`);
  }

  deleteEntry(id) {
    return this.http.delete(`${baseUrl + '/entry'}/${id}`);
  }

}
