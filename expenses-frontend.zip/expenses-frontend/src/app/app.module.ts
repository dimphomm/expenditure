import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTypeComponent } from './components/add-type/add-type.component';
import { AddEntryComponent } from './components/add-entry/add-entry.component';
import { TypeListComponent } from './components/type-list/type-list.component';
import { EntryListComponent } from './components/entry-list/entry-list.component';
import { TypeDetailsComponent } from './components/type-details/type-details.component';
import { EntryDetailsComponent } from './components/entry-details/entry-details.component';

@NgModule({
  declarations: [
    AppComponent,
    AddTypeComponent,
    AddEntryComponent,
    TypeListComponent,
    EntryListComponent,
    TypeDetailsComponent,
    EntryDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
