import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddTypeComponent } from './components/add-type/add-type.component';
import { AddEntryComponent } from './components/add-entry/add-entry.component';
import { TypeListComponent } from './components/type-list/type-list.component';
import { EntryListComponent } from './components/entry-list/entry-list.component';
import { TypeDetailsComponent } from './components/type-details/type-details.component';
import { EntryDetailsComponent } from './components/entry-details/entry-details.component';


const routes: Routes = [
  { path: '', redirectTo: 'expenses/type', pathMatch: 'full'},
  { path: 'expenses/type', component: TypeListComponent },
  { path: 'expenses/entry', component: EntryListComponent },
  { path: 'expenses/typeEntries/:id', component: EntryListComponent },
  { path: 'expenses/type/:id', component: TypeDetailsComponent },
  { path: 'expenses/entry/:id', component: EntryDetailsComponent },
  { path: 'addType', component: AddTypeComponent },
  { path: 'addEntry', component: AddEntryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
