const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

var corsOptions = {
  origin: "http://localhost:8081"
};

app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(bodyParser.json());

//added this for DB starts
const db = require("./app/models");
db.sequelize.sync({ force: false }).then(() => {
    console.log("Create Tables If NOT Exits - Drop and synch db.");
  });
//added this for DB ends

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Expenses Tracker Server." });
});

require("./app/routes/expense.routes")(app);//was added

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});