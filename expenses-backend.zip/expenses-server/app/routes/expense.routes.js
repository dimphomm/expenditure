module.exports = app => {
    const expenses = require("../controllers/expense.controller.js");
  
    var router = require("express").Router();
  
    // Create a new Expense Type
    router.post("/type", expenses.createType);

    // Create a new Expense Entry
    router.post("/entry", expenses.createEntry);

    // Find all Expense types
    router.get("/type", expenses.findAllTypes);

    // Find One Expense types
    router.get("/type/:id", expenses.findType);

    // Find all Expense entries
    router.get("/entry", expenses.findAllEntries);

     // Find One Expense entry
     router.get("/entry/:id", expenses.findEntry);

    // Find Expense type entries
    router.get("/typeEntries/:id", expenses.findTypeEntries);
  
    //Update a Expenses Type with id
    router.put("/type/:id", expenses.updateType);

    //Update a Expenses Entry with id
    router.put("/entry/:id", expenses.updateEntry);
  
    // Delete a Expenses Type with id
    router.delete("/type/:id", expenses.deleteType);
  
    // Delete a Expenses Entry with id
    router.delete("/entry/:id", expenses.deleteEntry);
  
    app.use('/api/expenses', router);
  };