module.exports = (sequelize, Sequelize) => {
  const Expense_types = sequelize.define("expense_types", {
    name: {
      type: Sequelize.STRING
    },
    comment: {
      type: Sequelize.STRING
    }
  });

  return Expense_types;
};
