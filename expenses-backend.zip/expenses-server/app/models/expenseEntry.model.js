module.exports = (sequelize, Sequelize) => {
    const Expense_entries = sequelize.define("expense_entries", {
    date: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW
    },
    typeId: {
        type: Sequelize.INTEGER
    },
    value: {
        type: Sequelize.INTEGER
    },
    comment: {
        type: Sequelize.STRING
    }
    });
    return Expense_entries;
};