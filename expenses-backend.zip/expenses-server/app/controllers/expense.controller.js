const db = require("../models");
const ExpenseType = db.expenseType;
const ExpenseEntry = db.expenseEntry;
// const Op = db.Sequelize.Op;

// Create and Save a new Expenses Type
exports.createType = (req, res) => {
  
};
// Create and Save a new Expenses Entry
exports.createEntry = (req, res) => {
  
};
// Retrieve all expenses types from the database.
exports.findAllTypes = (req, res) => {
  
};

// Retrieve expense type from the database.
exports.findType = (req, res) => {
  
};

// Retrieve all expenses entries from the database.
exports.findAllEntries = (req, res) => {
  
};

// Retrieve expense entry from the database.
exports.findEntry = (req, res) => {
  
};

// Find type entries
exports.findTypeEntries = (req, res) => {

};

// Update a Expenses Type by the id in the request
exports.updateType = (req, res) => {
  
};

// Update a Expenses Entry by the id in the request
exports.updateEntry = (req, res) => {
  
};

// Delete a Expenses Type with the specified id in the request
exports.deleteType = (req, res) => {
  
};

// Delete a Expenses Entry with the specified id in the request
exports.deleteEntry = (req, res) => {
  
};

//Create Expense Type
exports.createType = (req, res) => {
    // Validate request
    if (!req.body.name) {
      res.status(400).send({
        message: "Expense name can not be empty!"
      });
      return;
    }
  
    // Create an Expense Type
    const expense_type = {
      name: req.body.name,
      comment: req.body.comment,
    };
  
    // Save Expense type in the database
    ExpenseType.create(expense_type)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Expense name cannot be empty"
        });
      });

  };

  //Create Expense Entry
  exports.createEntry = (req, res) => {
    // Validate request
    if ((!req.body.typeId) && (!req.body.value)) {
      res.status(400).send({
        message: "Expense Type or Value cannot be empty"
      });
      return;
    }
    // Create an Expense Entry
    const expense_entry = {
      date: Date.now(),
      typeId: req.body.typeId,
      value: req.body.value,
      comment: req.body.comment,
    };
  
    // Save Expense entry in the database
    ExpenseEntry.create(expense_entry)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Expenses."
        });
      });
  };

  // Find all expenses types
  exports.findAllTypes = (req, res) => {
    const name = req.query.name;
    var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  
    ExpenseType.findAll({ where: condition })
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving expenses types."
        });
      });
  };
// Find One expense type
  exports.findType = (req, res) => {
    const id = req.params.id;
  
    ExpenseType.findByPk(id)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Expense type with id=" + id
        });
      });
  };

  // Find all expenses entries
  exports.findAllEntries = (req, res) => {
    const value = req.query.value;
    var condition = value ? { value: { [Op.like]: `%${value}%` } } : null;
  
    ExpenseEntry.findAll({ where: condition })
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving expenses types."
        });
      });
  };

  // Find One expense Entry
  exports.findEntry = (req, res) => {
    const id = req.params.id;
  
    ExpenseEntry.findByPk(id)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Expense Entry with id=" + id
        });
      });
  };

    // Find expense Type entries
    exports.findTypeEntries = (req, res) => {
      const typeId = req.query.typeId;
      var condition = typeId ? { typeId: { typeId } } : null;
    
      ExpenseEntry.findAll({ where: condition })
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving expenses type entries."
          });
        });
    };

  // Update expenses type with id
  exports.updateType = (req, res) => {
    const id = req.params.id;
  
    ExpenseType.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Expenses Type was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Expense Type with id=${id}. Maybe Expense was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Expense Type with id=" + id
        });
      });
  };

  exports.updateEntry = (req, res) => {
    const id = req.params.id;
  
    ExpenseEntry.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Expenses Entry was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Expense Entry with id=${id}. Maybe Expense was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Expense Entry with id=" + id
        });
      });
  };

  exports.deleteType = (req, res) => {
    const id = req.params.id;
  
    ExpenseType.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Expense Type was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Expense Type with id=${id}. Maybe Expense was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Expense Type with id=" + id
        });
      });
  };

  exports.deleteEntry = (req, res) => {
    const id = req.params.id;
  
    ExpenseEntry.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Expense Entry was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Expense Entry with id=${id}. Maybe Expense was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Expense Entry with id=" + id
        });
      });
  };